using Microsoft.EntityFrameworkCore;
using WebAPINatureHub3.Models;
using WebAPINatureHub3.Repos;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Register DbContext with SQL Server connection
builder.Services.AddDbContext<NatureHub3Context>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("NatureHubConstr"))
);

// Register repositories for Dependency Injection (DI)
builder.Services.AddScoped<IAdminRepository, AdminRepository>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IProductsRepository, ProductsRepository>();
builder.Services.AddScoped<ICartRepository, CartRepository>();
builder.Services.AddScoped<IRemediesRepository, RemediesRepository>();
builder.Services.AddScoped<IHealthTipsRepository, HealthTipsRepository>();
builder.Services.AddScoped<IAddressRepository, AddressRepository>();
builder.Services.AddScoped<IPaymentRepository, PaymentRepository>();
builder.Services.AddScoped<IBookmarkRepository, BookmarkRepository>();
builder.Services.AddScoped<IRolesRepository, RolesRepository>();
builder.Services.AddScoped<ICategoriesRepository,CategoriesRepository>();

// Add Swagger for API documentation
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Optional: Add logging (if desired)
builder.Services.AddLogging();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Authorization middleware (ensure this is configured correctly for your needs)
app.UseAuthorization();

// Map controllers
app.MapControllers();

app.Run();
