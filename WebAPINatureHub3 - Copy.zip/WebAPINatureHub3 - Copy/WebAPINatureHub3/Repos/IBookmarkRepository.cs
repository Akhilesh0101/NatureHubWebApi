﻿using WebAPINatureHub3.Models;

namespace WebAPINatureHub3.Repos
{
    public interface IBookmarkRepository
    {
        IEnumerable<Bookmark> GetAll();
        Bookmark GetById(int id);
        void Add(Bookmark bookmark);
        void Update(Bookmark bookmark);
        void Delete(int id);
    }
}
