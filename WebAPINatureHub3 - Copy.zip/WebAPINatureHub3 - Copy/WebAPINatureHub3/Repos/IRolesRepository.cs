﻿using WebAPINatureHub3.Models;

namespace WebAPINatureHub3.Repos
{
    public interface IRolesRepository
    {
        IEnumerable<Role> GetAll();
        Role GetById(int id);
        void Add(Role role);
        void Update(Role role);
        void Delete(int id);
    }
}
