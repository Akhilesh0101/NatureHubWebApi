﻿using WebAPINatureHub3.Models;

namespace WebAPINatureHub3.Repos
{
    public interface ICartRepository
    {
        IEnumerable<Cart> GetAll();
        Cart GetById(int id);
        void Add(Cart cart);
        void Update(Cart cart);
        void Delete(int id);
    }
}
