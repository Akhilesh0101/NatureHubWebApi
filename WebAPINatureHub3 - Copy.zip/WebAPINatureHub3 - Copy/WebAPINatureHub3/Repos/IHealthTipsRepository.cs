﻿using WebAPINatureHub3.Models;

namespace WebAPINatureHub3.Repos
{
    public interface IHealthTipsRepository
    {
        IEnumerable<HealthTip> GetAll();
        HealthTip GetById(int id);
        void Add(HealthTip healthTip);
        void Update(HealthTip healthTip);
        void Delete(int id);
    }
}
